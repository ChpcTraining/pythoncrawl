# from data import world, world2
from pythoncrawl.ascii_text import *
from pythoncrawl.data import world, world2


player = {
    "location": "forest",
    "health": 100,
    "inventory": ["map","scroll","key"]
}

def show_status():
    print(f"\nYou are in the {player['location']}.")
    print(f"Health: {player['health']}")
    print(f"Inventory: {', '.join(player['inventory']) if player['inventory'] else 'Empty'}")

def move(monstor):
    if monstor in world:
        # player["location"] = location
        # print(f"You move to the {location}.")
        encounter_challenge(monstor)
    else:
        print("Try again...!")

def move2(monstor):
    if monstor in world2:
        # player["location"] = location
        # print(f"You move to the {location}.")
        encounter_challenge2(monstor)
    else:
        print("Try again...!")

def encounter_challenge2(monstor):
    challenge = world2[monstor]["challenge"]
    if challenge:
        print(f"Challenge: {challenge}")
        answer = input("Your answer: ").strip().lower()
        if answer == world2[monstor]["answer"]:
            item = world2[monstor]["item"]
            print(item)
            if item not in player["inventory"]:
                print(f"Correct! Execute the command: {world2[monstor]['correct_response']}")
                while True:
                    user_command = input("Enter the command: ").strip()
                    if user_command == world2[monstor]["correct_response"]:
                        exec(user_command)
                        break
                    else:
                        print("Incorrect command. Try again.")
            else:
                print("Correct! But you already have this item in your inventory.")
        else:
            print(f"Incorrect! Execute the command: {world2[monstor]['incorrect_response']}")
            while True:
                user_command = input("Enter the command: ").strip()
                if user_command == world2[monstor]["incorrect_response"]:
                    exec(user_command)
                    break
                else:
                    print("Incorrect command. Try again.")

def encounter_challenge(monstor):
    challenge = world[monstor]["challenge"]
    if challenge:
        print(f"Challenge: {challenge}")
        answer = input("Your answer: ").strip().lower()
        if answer == world[monstor]["answer"]:
            item = world[monstor]["item"]
            if item not in player["inventory"]:
                print(f"Correct! Execute the command: {world[monstor]['correct_response']}")
                while True:
                    user_command = input("Enter the command: ").strip()
                    if user_command == world[monstor]["correct_response"]:
                        exec(user_command)
                        break
                    else:
                        print("Incorrect command. Try again.")
            else:
                print("Correct! But you already have this item in your inventory.")
        else:
            print(f"Incorrect! Execute the command: {world[monstor]['incorrect_response']}")
            while True:
                user_command = input("Enter the command: ").strip()
                if user_command == world[monstor]["incorrect_response"]:
                    exec(user_command)
                    break
                else:
                    print("Incorrect command. Try again.")

hp = True

def health_potion():
    global hp
    print("Correct! Execute the command: player['health'] += 15")
    while True:
        user_command = input("Enter the command: ").strip()
        if user_command == "player['health'] += 15":
            exec(user_command)
            hp = False
            break
        else:
            print("Incorrect command. Try again.")

def main():
    python_crawl()
    print("Welcome to PythonCrawl! Learn Python as you explore.")
    while player["health"] > 0:
        if "goblet" not in player["inventory"]:
            show_status()
            print("\n")
            command = input("Where do you want to explore? village/castle or quit:").lower()
            print("\n")
            if command == "quit":
                print("Goodbye! Keep coding!")
                break
            elif command == "village":
                player["location"] = "village"
                # List the keys dynamically from the 'world' dictionary
                print("You need to save the village from various monstors! \n")
                print("--- Which monster do you want to challenge? ---")
                for key in world.keys():
                    print(f"- {key}")

                command = input("Enter your choice: ").lower()
                print("\n")
                move(command)
            elif command == "castle":
                if "scroll" in player["inventory"]:
                    if "scroll" in player["inventory"]:
                        player["location"] = "castle"                    
                        if hp:
                            print("You find health potion when you enter!")
                            health_potion()
                        print("You then find yourself surrounded by more monstors... \n")
                        command = input(f"--- Which monster do you want to challenge? --- ({', '.join(world2.keys())}): ").lower()
                        move2(command)
                    else:
                        print("--- You need the key in your inventory to enter the castle --- \n")
                else:
                    print("--- Your missing the scroll in your inventory --- \n")
        else:
            well_done()
            print(f"Well Done! You have found the goblet! You have won the game!")
            break

    if player["health"] < 1:
        game_over()
        print(f"Game Over! Your Health is {player['health']} -> Your Quest Has Come To End...")

if __name__ == "__main__":
    main()
