world = {
    "vars": {
        "challenge": "The command to get the type of variable?",
        "answer": "type",
        "item": "map",
        "correct_response": "player['inventory'].append('map')",
        "incorrect_response": "player['health'] -= 5"
    },
    "oops": {
        "challenge": "What keyword is used to create a for-loop in Python?",
        "answer": "for",
        "item": "compass",
        "correct_response": "player['inventory'].append('compass')",
        "incorrect_response": "player['health'] -= 5"
    },
    "uncts": {
        "challenge": "What keyword is used to define a function in Python?",
        "answer": "def",
        "item": "gem",
        "correct_response": "player['inventory'].append('gem')",
        "incorrect_response": "player['health'] -= 5"
    },
    "ing": {
        "challenge": "What function is used to get the length of a string?",
        "answer": "len",
        "item": "scroll",
        "correct_response": "player['inventory'].append('scroll')",
        "incorrect_response": "player['health'] -= 5"
    },
    "ist": {
        "challenge": "Which method is used to add an item to a list in Python?",
        "answer": "append",
        "item": "potion",
        "correct_response": "player['inventory'].append('potion')",
        "incorrect_response": "player['health'] -= 5"
    },
    "ition": {
        "challenge": "What keyword is used to check a condition in Python?",
        "answer": "if",
        "item": "shield",
        "correct_response": "player['inventory'].append('shield')",
        "incorrect_response": "player['health'] -= 5"
    },
    "floops": {
        "challenge": "What keyword is used to create an infinite loop in Python?",
        "answer": "while",
        "item": "axe",
        "correct_response": "player['inventory'].append('axe')",
        "incorrect_response": "player['health'] -= 5"
    },
    "port": {
        "challenge": "What command is used to import a module in Python?",
        "answer": "import",
        "item": "book",
        "correct_response": "player['inventory'].append('book')",
        "incorrect_response": "player['health'] -= 5"
    },
    "ent": {
        "challenge": "What symbol is used to write a comment in Python?",
        "answer": "#",
        "item": "flower",
        "correct_response": "player['inventory'].append('flower')",
        "incorrect_response": "player['health'] -= 5"
    },
    "ype": {
        "challenge": "What data type is used to store true/false values in Python?",
        "answer": "bool",
        "item": "key",
        "correct_response": "player['inventory'].append('key')",
        "incorrect_response": "player['health'] -= 5"
    }
}

world2 = {
    "felse": {
        "challenge": "Which keyword is used to specify an alternative block if the condition is false?",
        "answer": "else",
        "item": "arrow",
        "correct_response": "player['inventory'].append('arrow')",
        "incorrect_response": "player['health'] -= 5"
    },
    "return": {
        "challenge": "Which keyword is used to return a value from a function?",
        "answer": "return",
        "item": "potion",
        "correct_response": "player['inventory'].append('potion')",
        "incorrect_response": "player['health'] -= 5"
    },
    "class": {
        "challenge": "Which keyword is used to define a class in Python?",
        "answer": "class",
        "item": "ring",
        "correct_response": "player['inventory'].append('ring')",
        "incorrect_response": "player['health'] -= 5"
    },
    "tryexcept": {
        "challenge": "Which keyword is used to handle exceptions in Python?",
        "answer": "try",
        "item": "staff",
        "correct_response": "player['inventory'].append('staff')",
        "incorrect_response": "player['health'] -= 5"
    },
    "upper": {
        "challenge": "Which string method converts all characters to uppercase?",
        "answer": "upper",
        "item": "stone",
        "correct_response": "player['inventory'].append('stone')",
        "incorrect_response": "player['health'] -= 5"
    },
    "split": {
        "challenge": "Which string method splits a string into a list?",
        "answer": "split",
        "item": "rune",
        "correct_response": "player['inventory'].append('rune')",
        "incorrect_response": "player['health'] -= 5"
    },
    "join": {
        "challenge": "Which string method joins elements of a list into a string?",
        "answer": "join",
        "item": "charm",
        "correct_response": "player['inventory'].append('charm')",
        "incorrect_response": "player['health'] -= 5"
    },
    "replace": {
        "challenge": "Which string method replaces parts of a string?",
        "answer": "replace",
        "item": "cloak",
        "correct_response": "player['inventory'].append('cloak')",
        "incorrect_response": "player['health'] -= 5"
    },
    "math": {
        "challenge": "Which built-in Python module provides mathematical functions?",
        "answer": "math",
        "item": "orb",
        "correct_response": "player['inventory'].append('orb')",
        "incorrect_response": "player['health'] -= 5"
    },
    "random": {
        "challenge": "Which module is used for generating random numbers in Python?",
        "answer": "random",
        "item": "cube",
        "correct_response": "player['inventory'].append('cube')",
        "incorrect_response": "player['health'] -= 5"
    },
    "datetime": {
        "challenge": "Which module is used for handling dates and times in Python?",
        "answer": "datetime",
        "item": "crystal",
        "correct_response": "player['inventory'].append('crystal')",
        "incorrect_response": "player['health'] -= 5"
    },
    "os": {
        "challenge": "Which module is used to interact with the operating system?",
        "answer": "os",
        "item": "goblet",
        "correct_response": "player['inventory'].append('goblet')",
        "incorrect_response": "player['health'] -= 5"
    }
}

